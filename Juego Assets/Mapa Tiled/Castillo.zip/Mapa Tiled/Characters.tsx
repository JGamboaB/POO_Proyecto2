<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Characters" tilewidth="16" tileheight="16" tilecount="96" columns="12">
 <image source="../Nuevo/characters.png" width="192" height="128"/>
</tileset>
