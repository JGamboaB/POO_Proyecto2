<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Overworld" tilewidth="16" tileheight="16" tilecount="1440" columns="40">
 <image source="../Viejo/gfx/Overworld.png" width="640" height="576"/>
</tileset>
